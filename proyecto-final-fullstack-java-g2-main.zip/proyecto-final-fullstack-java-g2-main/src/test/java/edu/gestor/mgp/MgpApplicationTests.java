package edu.gestor.mgp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MgpApplicationTests {

	@Test
	void contextLoads() {
	}

}
