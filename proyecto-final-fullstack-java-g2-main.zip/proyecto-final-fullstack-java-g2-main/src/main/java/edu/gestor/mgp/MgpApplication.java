package edu.gestor.mgp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MgpApplication {

	public static void main(String[] args) {
		SpringApplication.run(MgpApplication.class, args);
	}

}
