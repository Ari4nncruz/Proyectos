package edu.gestor.mgp.model;

public enum Rol {
    usuario_normal,
    usuario_administrador
}
